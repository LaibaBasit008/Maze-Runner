package project.oop.MazeRunner.Manager;

public class Data {

}
